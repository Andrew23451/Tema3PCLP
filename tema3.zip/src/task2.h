#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "task1.h"
#include "../include/structuri.h"
